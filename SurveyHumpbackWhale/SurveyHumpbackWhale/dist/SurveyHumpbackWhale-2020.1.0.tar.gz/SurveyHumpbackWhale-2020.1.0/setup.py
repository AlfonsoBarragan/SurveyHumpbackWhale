import setuptools


setuptools.setup(
    name='SurveyHumpbackWhale',
    version='2020.1.0',
    description='Survey utils module to make transforms and proccess this sources of data easily',
    py_modules=["SurveyHumpbackWhale"],
    )

