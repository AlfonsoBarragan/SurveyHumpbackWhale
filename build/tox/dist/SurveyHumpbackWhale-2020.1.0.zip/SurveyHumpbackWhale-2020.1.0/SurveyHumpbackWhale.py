
import numpy as np
import re

""" SurveyHumpbackWhale is a module with the purpouse of automatize tasks in order to proccess survey's data easily.

This module mainly transform the answers into numbers in order of aplying learning algorithms like clustering or
random forests. Also it has some functions that correct errors in surveys or combine the free comments columns
with electable answers included (in example, in a survey with a question of the most used apps, we can include
answers and a free comment answer where the user writes what he want. This function module can combine this 
free question with the tipo question that are included in the survey.).

    Typical usage example:
        
    import SurveyHumpbackWhale as surv_whale
    import pandas as pd
    
    dataset_survey = pd.read_csv(path, separator=',')
    comment_columns = surv_whale.comment_columns_detector(dataset_survey) # Detects comment columns.
    surv_whale.aglutinate_comment_columns(dataset_survey, comment_columns) # Combine the comment columns with survey tipo answers.
"""

# Regular expressions to make transforms in the data
_re_words_finder        = re.compile(r"[a-zA-ZáéíóúÁÉÍÓÚ]*")
_re_comment_pattern     = re.compile(r"-COMENTARIO-|-COMMENT-")
_re_digit_pattern       = re.compile(r"[\d|\d\.]*")
_re_zero_pattern        = re.compile(r"ningún|solo|ninguno|ninguna|nadie|no recuerdo|no lo sé|desconozco|only|no one|no one|I don't remember|I don't know")
_re_error_pattern       = re.compile(r"aaa Not A Number aaa")

# Corpus of language particles

corpus_lang_particles = {'Greater_particles':['más', 'more', 'with more'], 
                         'Middle_particles':['entre', 'between', 'de', 'from'], 
                         'Lesser_particles':['menos','less', 'hasta', 'with less']}

def list_to_num_dict(list_elements):

    dictionary = {}
    
    for element in list_elements:
        try:
            element = int(element)
            dictionary[element] = element
        except ValueError:
            dictionary[element] = len(dictionary)
            
            
    return dictionary

def map_answers_to_categories(dataset):
    
    """Maps survey answers in a dataset to a dictionary in order of transform to numbers later.
    
    Maps every answer to the survey recollected in the dataset in order of transform all of
    that to ordinal variables. Also it takes in consideration important language quantifiers
    like 'Between' or 'More' to make this kind of permutations.
    
    Args:
        dataset: A dataset divided in columns and rows, like DataFrame from pandas module.
        
    Returns:
        A dict that map every answer (dataset value in column j and row i) to every question
        of the survey (dataset column name). For example:
            
        For a dataset like this:        
        
        dataset = pd.DataFrame(data = {'Do you like this python module?': ['Yes', 'No'], 
                                       'How useful do you thing it is from 1 to 10?': [3, 8]})
        
        This function returns a dict like this:
            
        dict_data = {0: {'question':'Do you like this python module?', 'answers':{'No':0, 'Yes':1}}
                     1: {'question':'How useful do you thing it is from 1 to 10?', 'answers':{'3':3, '8':8}}}
    """

    answers_key_value = {} # Dict to store the survey structure.
    
    columns_data    = dataset.columns # Columns of dataset (as known as survey questions).
    
    for index, column in enumerate(columns_data):
        answers = list(dataset[column].unique()) # Take all kind of the answers giving to the question and converts it in a list.
        
        # Now we try to remove the nan data that can be in the survey and 
        # replace it by a string that can be manipulate easily. It can raise
        # a ValueError exception if there isn't a nan value in the answers, in
        # that case nothing needs to be changed.
        
        try: 
            answers.remove(np.nan)
            answers.append('aaa Not A Number aaa')
            
        except ValueError:
            pass
        
        # In this part we look if there are some language particle that
        # denotates the existence of a range of values, in case that we find
        # words like 'Between' or 'More', we proceed to make an smart sort of
        # answers. Otherwise, we just orther the answers alphabetically. If 
        # all the answers are numbers, it can raises a TypeError and then 
        # just need to sort the answers.
        
        try:
            if (_re_words_finder.findall(answers[0])[0] == 'De' or 
                _re_words_finder.findall(answers[0])[0] == 'Between' or 
                _re_words_finder.findall(answers[0])[0] == 'Entre' or
                (_re_words_finder.findall(answers[0])[0] == 'With' and
                 _re_words_finder.findall(answers[0])[2] == 'more')):
                answers = smart_answers_sort(answers)
            
            else: 
                answers.sort()
            
        except TypeError:
            answers.sort()
        
        # Finally we add to the dictionary that has all the questions, answers and its
        # transformation to number the dictionary with the question (column) and the 
        # dictionary of all the answers finded, created by an auxiliar function.
        
        answers_key_value[index] = {'question':column, 'answers': list_to_num_dict(answers)}    
        
    return answers_key_value

def proccess_list_entry(dataset, columns_to_look_at):
    """Process a list entry obtained from a multiple answer in a survey.
    
    Process a list entry obtained from a question with multiple answers in a survey
    
    
    """
    
    new_columns = []
    for column in columns_to_look_at:
        for value in dataset[dataset.columns[column]].unique():
            try:
                aux = value.replace("[", "").replace("]", "")
                
                for new_column in aux.split(","):
                    
                    if new_column[0] == " ":
                        aux_new_column = new_column[1:]
                    else:
                        aux_new_column = new_column
            
                    if aux_new_column != 'other':
                        
                        if aux_new_column == 'Ninguno' or aux_new_column == 'Ninguna' or aux_new_column == 'Nimguno' or aux_new_column == 'Nimguna':
                            aux_new_column = '{}_Ninguno'.format(dataset.columns[column])

                        else:
                            aux_new_column = '{}_{}'.format(dataset.columns[column], aux_new_column)
                 
                        if aux_new_column not in new_columns:
                            new_columns.append(aux_new_column)
                    
            except AttributeError:
                pass           
            
            
    return new_columns

def aglutinate_comment_columns(dataset, columns_to_look_at):
    other_pattern       = re.compile(r"other")
    
    for column in columns_to_look_at:
        
        for row_index in range(len(dataset)):            
            if other_pattern.search(str(dataset.iloc[row_index, column - 1])):
                phrase      = str(dataset.iloc[row_index, column - 1])
                location    = other_pattern.search(phrase)
                
                if phrase[0:location.start()] + phrase[location.end():] != '':
                    dataset.iloc[row_index, column - 1] = phrase[0:location.start()] + " " + dataset.iloc[row_index, column] + " " + phrase[location.end():]
                
                else:
                    dataset.iloc[row_index, column - 1] = dataset.iloc[row_index, column]
                
            
            elif other_pattern.search(str(dataset.iloc[row_index, column + 1])):
                phrase      = str(dataset.iloc[row_index, column + 1])
                location    = other_pattern.search(phrase)
                
                if phrase[0:location.start()] + phrase[location.end():] != '':
                    dataset.iloc[row_index, column + 1] = phrase[0:location.start()] + " " + dataset.iloc[row_index, column] + " " + phrase[location.end():]
                
                else:
                    dataset.iloc[row_index, column + 1] = dataset.iloc[row_index, column]
                
def comment_columns_detector(dataset):
    columns_list = list(dataset.columns)
    comment_columns = []
    columns_to_look_at = []
    
    
    for column_index in range(len(columns_list)):
        if _re_comment_pattern.search(columns_list[column_index]):
            comment_columns.append(column_index)
            columns_to_look_at.append(column_index)
        
    return comment_columns
                            
def fix_date_format(df, columns_with_dates):
    
    for column in columns_with_dates:
        aux = df[column].str.contains('[0-9]*\.[0-9]*\.[0-9]*')
        
    return aux

def smart_answers_sort(answers_list):
    
    """Sorts the answers from a survey stored in a dataframe.
    
    Sorts the answers from a survey stored in a dataframe in consideration
    of the answer represents a range by locating language particles that has 
    implicit meaning of range (ie: 'Between' or 'Less ... than').
    
    Args:
        answers_list: A list with the answers that can had a meaning of range.
        
    Returns:
        A list that contains all the answers from answers_list but ordered in
        function of the ranges that represents.
    """
    
    answers_examples = {}
    answer_not_numeric = 0
    
    for element in answers_list:
        
        # First, we extract the numeric elements and word elements from an 
        # answer throught the regular expressions defined at the begining of
        # the module. 
        
        digit_list = _re_digit_pattern.findall(element)
        clean_digit_list = list(filter(None, digit_list))
        
        words_list = _re_words_finder.findall(element)
        clean_words_list = list(filter(None, words_list))
        
        # Then we make a transform in the numeric elements converting it to 
        # python format. This is because the number format from the surveys 
        # (ie: 2.000 or 1,23 in survey and 2000 or 1.23 in python).

        clean_digit_list = smart_digit_conversion(clean_digit_list)        
    
        # Checks if the answer is contextually null (ie: for question, 'How 
        # many people live with you?, the answer 'alone' it's equivalent to 0).
        
        if _re_zero_pattern.findall(element.lower()):
            answers_examples[answers_list.index(element)] = 0
            answer_not_numeric = answers_list.index(element)
            
        
        elif _re_error_pattern.findall(element.lower()):
            answers_examples[answers_list.index(element)] = -99           
            answer_not_numeric = answers_list.index(element)

        else:
            
            # Identifies the kind of particle with the corpus of particles defined at
            # the begin of the module and took a represent of the range in function of
            # the particle.
            
            if (clean_words_list[0].lower() in corpus_lang_particles['Greater_particles'] or
                ("{} {}".format(clean_words_list[0].lower(), clean_words_list[1].lower()) in corpus_lang_particles['Greater_particles'])):
                answers_examples[answers_list.index(element)] = clean_digit_list[0] + 1

            elif (clean_words_list[0].lower() in corpus_lang_particles['Middle_particles']):
                answers_examples[answers_list.index(element)] = (clean_digit_list[0] + clean_digit_list[1]) / 2
            
            elif (clean_words_list[0].lower() in corpus_lang_particles['Lesser_particles'] or
                ("{} {}".format(clean_words_list[0].lower(), clean_words_list[1].lower()) in corpus_lang_particles['Lesser_particles'])):
                answers_examples[answers_list.index(element)] = clean_digit_list[0] - 1
    
    # Finally, we acummulated the answers with the 'represent' of its range and
    # we sort them.                
    
    answers_examples_def = {k: v for k, v in sorted(answers_examples.items(), key=lambda item: item[1])}

    definitive_answers_list = []
    
    for answer in list(answers_examples_def.keys()):
        definitive_answers_list.append(answers_list[answer])
        
    return definitive_answers_list

def smart_digit_conversion(digit_list):
    
    """Converts the survey number format to python number format
    
    Converts the numeric answers from a survey like 2.000 or 1,23; to the 
    python number format like 2000 or 1.23 in order of evade errors.
    
    Args:
        digit_list: A list of the digits to be converse.
        
    Returns:
        A new digit list in the python numeric format.
    """
    
    new_digit_list = []
    
    for digit in digit_list:
        if digit.find('.') != -1:
            new_digit = digit.replace('.','')
            new_digit_list.append(int(new_digit))
        elif digit.find(',')  != -1:
            new_digit = digit.replace(',','.')
            new_digit_list.append(float(new_digit))
        
        else:
            new_digit_list.append(int(digit))

    return new_digit_list

def traduce_survey_with_dictionary(dict_traduction, dataset):
    
    """Traduces a survey answers dataframe with a dictionary.
    
    Traduces the dataframe that represents questions and answers from a survey
    in function of a dictionary which key represents the non traduce part of
    the dataset and value represents the traduction. Sometimes its useful to
    make multilangual surveys and this function helps to mix various sources
    of data.
    
    Args: 
        dict_traduction: Dictionary who directs the traduction process. Keys 
                        are the value that needs to be traduced and values are
                        its traduction.
        dataset: A pandas dataframe that needs to be traduced.
        
    Returns:
        A new dataframe completly traduced.
    """
    
    dataset_to_work = dataset.copy()
    
    for key in list(dict_traduction.keys()):
        
        key_to_search = key.replace('(','\(').replace(')','\)').replace('[','\[').replace(']','\]')
        dataset_to_work = dataset_to_work.replace(to_replace=key_to_search, value=dict_traduction[key],regex=True)
        
        
    return dataset_to_work

def create_and_poblate_new_columns(dataset_base, new_columns):
    
    for column in new_columns:
        base_column = column.split('_')[0]
        new_name_column = column.split('_')[1]
        dataset_base[column] = 0
                
        rastreator = re.compile(r'{}\b'.format(new_name_column))
        index = 0
        for row in dataset_base[base_column]:
            try:
                if re.search(rastreator, row):
                    dataset_base.loc[index, column] = 1
            
            except TypeError:
                pass
            
            index += 1
            
def detect_differences_between_dataset_columns(dataset_1, dataset_2):
    columns_dataset_1 = list(dataset_1.columns)
    columns_dataset_2 = list(dataset_2.columns)
    
    lost_columns_in_dataset = {}
    if len(columns_dataset_1) > len(columns_dataset_2):
        lost_columns_in_dataset['dataset_2'] = []
        
        for column in columns_dataset_1:
            if column not in columns_dataset_2:
                lost_columns_in_dataset['dataset_2'].append(column)

    else:
        lost_columns_in_dataset['dataset_1'] = []
        
        for column in columns_dataset_2:
            if column not in columns_dataset_1:
                lost_columns_in_dataset['dataset_1'].append(column)
                
    return lost_columns_in_dataset


def fill_lost_columns(dataset_1, dataset_2, lost_columns_dict):
    if list(lost_columns_dict.keys())[0] == 'dataset_1':
        for column in lost_columns_dict['dataset_1']:
            dataset_1[column] = 0
            
    else:
        for column in lost_columns_dict['dataset_2']:
            dataset_2[column] = 0
            
def reorder_columns_of_dataset(dataset):
    columns_list = dataset.columns.tolist()
    columns_list.sort()
    
    dataset = dataset[columns_list]
    
    return dataset   

